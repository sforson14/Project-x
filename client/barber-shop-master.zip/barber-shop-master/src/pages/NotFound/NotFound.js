import React from 'react';
import { Link } from 'react-router-dom';

import Layout from '../../layout/Layout';



const NotFound = () => {

  return (
    <Layout>

    </Layout>
  );
};

export default NotFound;
