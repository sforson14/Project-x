export const APP_NAME = "Stanar";
export const SERVER_URL = "https://stanartest.co.uk/web-api-barber-shop/public/api/";
export const SERVER = "https://stanartest.co.uk/web-api-barber-shop/";
export  const GoogleMapsAPI  = "AIzaSyDR5-GEgHP3kHq7bPnMOZJDpe7D8BC9CUM"

export const STRIPE_KEY_LIVE = "pk_live_51JAsGjBSXseCpcQdOXRfHN1wcPl3AUupf5kWV38NuodlkeZHFaCfHqE6BKGjZUJCMnAlkvx3IQVnV0FYFvzFi9cE00SxEKoVqa"

export  const STRIPE_PUBLIC_KEY_SANDBOX = "pk_test_51JAsGjBSXseCpcQdhWpQUCSKwptVKkRNxjtnWwAfg0v2KBJjkA7x5lvW5zBrUwAxO8tx3VW7dKvcshBAWR9jfbor00pTnqN7LG"
export  const STRIPE__SECRET_KEY_SANDBOX = "sk_test_51JAsGjBSXseCpcQd2K3k7eirld6k7j5eyrzsJTED3SlzQKDWxC2VHjCDA4PmxOLd2ZVf1c2LiUv9GGMEHIBnGPpe00VmdWfLke"