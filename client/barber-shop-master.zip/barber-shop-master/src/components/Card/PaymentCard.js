import React from 'react'

const PaymentCard = () => {
    return(

    )
}

export default PaymentCard